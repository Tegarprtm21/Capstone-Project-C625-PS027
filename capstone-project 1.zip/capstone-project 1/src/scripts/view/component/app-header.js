class Appder extends HTMLElement {
    connectedCallback() {
      this.render();
    }
  
    render() {
      this.innerHTML = `
          <div class="container">
          <div class="left-div">
              <div class="text-container">
                <p class="large-text">EcoFriends</p>
                <p class="medium-text">Dari Sampah Menjadi Manfaat</p>
                <div class="green-line"></div>
                <p class="small-text">Meningkatkan kesadaran masyarakat tentang <br>pengelolaan sampah dan mendorong tindakan<br> yang lebih bertanggung jawab terhadap<br> lingkungan.</p>
              </div>
          </div>
          <div class="right-div">
            <div class="container">
              <div class="rounded-rectangle">
                
              </div>
            </div>
          </div>
          </div>

          <div class="container3">
          <div class="box1">
            <div class="square"></div>
          </div>
          <div class="box">
            <div class="container4">
              <p class="large-text4">EcoFriends<br>Informasi</p>
              <p class="small-text4">Identifikasi sampah<br> berdasarkan jenis, cara <br>pengolahan dan daur <br>ulang yang tepat.</p>
              <a href="#" class="button">Lebih Lanjut</a>
            </div>
          </div>
          <div class="box">
          <div class="container4">
              <p class="large-text4">EcoFriends<br>Diskusi</p>
              <p class="small-text4">Ruang diskusi untuk <br>pengguna agar dapat berbagi <br>ide, pengalaman, dan pengetahuan<br> mengenai pengelolaan sampah.</p>
              <a href="#" class="button">Sign In</a>
            </div>
          </div>
          <div class="box">
          <div class="container4">
              <p class="large-text4">EcoFriends<br>Upload Konten</p>
              <p class="small-text4">Mengunggah menggunakan <br>tautan youtube tentang aktivitas <br>pengelolaan sampah, seperti daur <br>ulang atau penggunaan kembali. </p>
              <a href="#" class="button">Sign In</a>
            </div>
          </div>
          </div>

          <div class="bagian1">
            <div>
              <p class="text1">Recycling Starts with <br>YouThink Green Act<br> Clean</p>
              <p class="text2">Invite each individual to take personal<br> responsibility in recycling. emphasizes that <br>everyone has an important role in the <br>recycling process, starting from everyday<br> decisions to sort waste. Reminding us to<br> consider the environmental impact of our<br> actions, encouraging real and clean actions <br>to keep the environment clean through <br>proper recycling.</p>
            </div>
          </div>

          
          <div class="grid-containerv">
            <div class="boxv box-leftv"></div>

            <div class="boxv box-centerv">
              <div class="aboutus">About Us</div>
              <div class="about-p">EcoFriend adalah platform yang<br>
               didedikasikan untuk meningkatkan<br> kesadaran dan tindakan terhadap <br>
               lingkungan melalui edukasi,<br>
                identifikasi sampah, dan konektivitas<br>
                 sosial. Kami percaya bahwa setiap <br>
                 individu memiliki peran penting <br>
                 dalam menjaga kelestarian bumi, dan<br>
                  tujuan kami adalah menyediakan alat<br>
                   dan pengetahuan yang dibutuhkan <br>
                   untuk membuat perbedaan nyata.</div>
                   <div class="about-p">Koneksikan forum di website ini dan<br>
                    bersama-sama kita wujudkan bumi<br>
                     yang lebih hijau dan bersih untuk<br>
                      generasi mendatang.</div>

                      <div class="b-about" ><a href="#" class="button-aboutus">details</a></div>
            </div>
            <div class="boxv box-rightv">
              <div class="box-rightv-p">Kenapa ecoFriends ?</div>
              <div class="about-p">Masalah pencemaran dan sampah semakin parah. Banyak yang ingin berkontribusi tetapi bingung memulai. EcoFriend memberikan informasi jelas dan ruang diskusi untuk mendukung setiap langkah kecil menuju perubahan besar.</div>
              <div class="about-p"><b>Information</b> regarding the identification of waste around us and the surrounding environment based on types and groups, as well as the impact and usefulness of waste or reprocessing steps</div>
              <div class="about-p"><b>Uploading</b> activities to anticipate, overcome, or reuse and recycle from individual users of the EcoFriend website the waste around them</div>
              <div class="about-p"><b>Connecting</b> each individual user of the EcoFriend website in a community forum or discussion room to exchange ideas with the aim of building a better community and sharing experiences, information and knowledge to increase mutual awareness.</div>
            </div>
          
            
          </div>

          <div class="bagian5">
          <div class="container6">
          <p class="large-text5">Information</p>
          <p class="small-text5">Contains pages regarding blog news, information or activities<br> regarding recycling and waste</p>
          <a href="#" class="button">details</a>
          </div>
          </div>

          
          <div class="bagian3">
            <div class="container7">
              <p class="large-text6">Information</p>
              <p class="small-text6">Contains pages regarding blog news, information or activities<br> regarding recycling and waste</p>
              <a href="#" class="button">details</a>
            </div>   
          <div>
          
          

          <diV class="new">
          
          </div>
        
          
          `;
    }
  }
  
  customElements.define('app-der', Appder);
  