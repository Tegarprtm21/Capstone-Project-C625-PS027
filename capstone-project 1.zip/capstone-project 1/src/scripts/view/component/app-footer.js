class Footer extends HTMLElement {
    connectedCallback() {
      this.render();
    }
  
    render() {
      this.innerHTML = `
        <footer>
          <div class="footer-content">
              <p class="right-text">Work Hours<br><br>7 AM - 5 PM<br>MONDAY - SATURDAY<br><br>for quick<br>Information</p>  
              
          </div>
          <div class="f-button">
          <a href="#" class="button-footer">call us</a>  </div>
          <div class="footer-line"></div>
          <p class="footer-p">@ 2024 - Developed by ecoFriends - All Right Reserved<p>
        </footer>
      `;
    }
  }
  
  customElements.define('app-footer', Footer);