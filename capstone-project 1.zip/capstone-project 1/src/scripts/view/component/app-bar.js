class Appbar extends HTMLElement {
    connectedCallback() {
      this.render();
    }
  
    render() {
      this.innerHTML = `
      <nav class="navbar">
        <div class="navbar-brand">EcoFriend</div>
        <ul class="navbar-menu">
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About us</a></li>
            <li><a href="#services">Information</a></li>
            <li><a href="#contact">Sign In | Sign Up</a></li>
        </ul>
      
    </nav>
    
          `;
    }
  }
  
  customElements.define('app-bar', Appbar);
  