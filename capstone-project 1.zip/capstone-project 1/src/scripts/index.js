import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../scripts/view/component/app-bar';
import './view/component/app-header';
import './view/component/app-footer';


console.log('Hello Coders! :)');
